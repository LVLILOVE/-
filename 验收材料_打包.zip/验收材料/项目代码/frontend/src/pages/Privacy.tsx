// ============================================================
// 代码段功能：隐私政策页（对齐 PRD §4.6 与 UIUX §4.7）
// - 纯文本排版：收集范围 / 用途 / 不共享 / 删除方式
// ============================================================

export default function Privacy() {
  return (
    <div className="max-w-[680px] mx-auto px-5 md:px-10 pt-32 pb-16">
      <h1 className="text-[26px] tracking-[0.2em] font-semibold text-center mb-8">隐私政策</h1>
      <div className="bg-card border border-line rounded-2xl p-7 md:p-9 text-[14px] leading-[1.9] text-ink-soft space-y-5">
        <section>
          <h2 className="text-[15px] font-semibold text-ink mb-2">我们收集哪些信息</h2>
          <p>为提供预约与领养服务，我们仅收集您主动填写的信息：姓名、手机号（预约与领养联系用），以及领养申请中的居住情况、养宠经验与环境照片。</p>
        </section>
        <section>
          <h2 className="text-[15px] font-semibold text-ink mb-2">信息的用途</h2>
          <p>以上信息仅用于：预约确认与到店联系、押金核验沟通、领养审核与回访。我们不会将您的信息用于任何其他用途。</p>
        </section>
        <section>
          <h2 className="text-[15px] font-semibold text-ink mb-2">信息共享</h2>
          <p>我们不会向任何第三方出售、出租或共享您的个人信息，法律法规另有规定或经您单独同意除外。</p>
        </section>
        <section>
          <h2 className="text-[15px] font-semibold text-ink mb-2">信息存储与删除</h2>
          <p>您的信息存储于服务器本地数据库。如需删除您的申请记录（如预约或领养申请），请联系店主，我们将在核实后删除。</p>
        </section>
        <section>
          <h2 className="text-[15px] font-semibold text-ink mb-2">联系我们</h2>
          <p>如有任何隐私相关疑问，请到店或通过门店电话联系店主。</p>
        </section>
      </div>
    </div>
  )
}
